﻿<?php
echo "123456";
echo "</br>";
echo "12345678";
echo "</br>";
echo "admin";
echo "</br>";
$post_namejp=htmlspecialchars($_POST['namejp']);
$post_nameqp=htmlspecialchars($_POST['nameqp']);
$post_ename=htmlspecialchars($_POST['ename']);
$post_username=htmlspecialchars($_POST['username']);
$post_tel=htmlspecialchars($_POST['tel']);
$post_qq=htmlspecialchars($_POST['qq']);
$post_birth=htmlspecialchars($_POST['birth']);
$post_num=htmlspecialchars($_POST['num']);
$post_email=htmlspecialchars($_POST['email']);
$post_pass=htmlspecialchars($_POST['pass']);
$post_wifejp=htmlspecialchars($_POST['wifejp']);
$post_wifeqp=htmlspecialchars($_POST['wifeqp']);

$null="";

if (($post_namejp==$null) && ($post_nameqp==$null) && ($post_ename==$null) && ($post_username==$null)&& ($post_tel==$null)&& ($post_qq==$null)&& ($post_birth==$null)&& ($post_num==$null)&& ($post_email==$null)&& ($post_pass==$null)&& ($post_wifejp==$null)&& ($post_wifeqp==$null))
{echo"请输入内容！";}

    function pass_Attack_1($Pass_1 = "woaini")
    {

        echo strtolower($Pass_1);
        echo "</br>";

        echo strtolower($Pass_1), ".";
        echo "</br>";

        echo strtoupper($Pass_1);
        echo "</br>";

        echo strtoupper($Pass_1), ".";
        echo "</br>";

    }

    if ($post_namejp == $null)
        echo "";
    else
        Pass_Attack_1($post_namejp);
    if ($post_nameqp == $null)
        echo "";
    else
        Pass_Attack_1($post_nameqp);
    if ($post_username == $null)
        echo "";
    else
        Pass_Attack_1($post_username);
    function pass_Attack_2($Pass_2 = "woaini")


    {

        echo strtolower("woaini");
        echo "</br>";

        echo strtolower("woaini"), ".";
        echo "</br>";

        echo strtoupper("woaini");
        echo "</br>";

        echo strtoupper("woaini"), ".";
        echo "</br>";

        echo "woaini", strtolower($Pass_2);
        echo "</br>";

        echo "woaini", strtolower($Pass_2), ".";
        echo "</br>";

        echo "520", strtolower($Pass_2);
        echo "</br>";

        echo "520", strtolower($Pass_2), ".";
        echo "</br>";

        echo "woaini", strtoupper($Pass_2);
        echo "</br>";

        echo "woaini1314", strtoupper($Pass_2);
        echo "</br>";

        /**echo strtolower($Pass_2), "lovewifejp";
        echo "</br>";

        echo strtolower($Pass_2), "lovewifejp.";
        echo "</br>";

        echo strtoupper($Pass_2), "LOVEWIFEJP";
        echo "</br>";

        echo strtoupper($Pass_2), "LOVEWIFEJP.";
        echo "</br>";**/

    }

    if ($post_namejp == $null)
        echo "";
    else
        Pass_Attack_2($post_namejp);
    if ($post_namejp == $null)
        echo "";
    else
        Pass_Attack_4($post_namejp);


    function pass_Attack_3($Pass_3 = "woaini")
    {

        echo strtolower($Pass_3), "lovewifejp";
        echo "</br>";

        echo strtolower($Pass_3), "lovewifejp.";
        echo "</br>";

        echo strtoupper($Pass_3), "LOVEWIFEJP";
        echo "</br>";

        echo strtoupper($Pass_3), "LOVEWIFEJP.";
        echo "</br>";

    }

    if ($post_nameqp == $null)
        echo "";
    else
        Pass_Attack_3($post_nameqp);
    if ($post_nameqp == $null)
        echo "";
    else
        Pass_Attack_4($post_nameqp);


    function pass_Attack_4($Pass_4 = "woaini")
    {
        echo strtolower($Pass_4), "123123";
        echo "</br>";
        echo strtolower($Pass_4), "123";
        echo "</br>";
        echo strtolower($Pass_4), "123456";
        echo "</br>";
        echo strtolower($Pass_4), "123123.";
        echo "</br>";

        echo strtoupper($Pass_4), "123123";
        echo "</br>";

        echo strtoupper($Pass_4), "123123.";
        echo "</br>";

        echo strtolower($Pass_4), "123123123";
        echo "</br>";

        echo strtolower($Pass_4), "123123123.";
        echo "</br>";

        echo strtoupper($Pass_4), "123123123";
        echo "</br>";

        echo strtoupper($Pass_4), "123123123.";
        echo "</br>";

        echo strtolower($Pass_4), "112233";
        echo "</br>";

        echo strtolower($Pass_4), "112233.";
        echo "</br>";

        echo strtoupper($Pass_4), "112233";
        echo "</br>";

        echo strtoupper($Pass_4), "112233.";
        echo "</br>";

        echo strtolower($Pass_4), "445566";
        echo "</br>";

        echo strtolower($Pass_4), "445566.";
        echo "</br>";

        echo strtoupper($Pass_4), "445566";
        echo "</br>";

        echo strtoupper($Pass_4), "445566.";
        echo "</br>";

        echo strtolower($Pass_4), "456456";
        echo "</br>";

        echo strtolower($Pass_4), "456456.";
        echo "</br>";

        echo strtoupper($Pass_4), "456456";
        echo "</br>";

        echo strtoupper($Pass_4), "456456.";
        echo "</br>";

        echo strtolower($Pass_4), "778899";
        echo "</br>";

        echo strtolower($Pass_4), "778899.";
        echo "</br>";

        echo strtoupper($Pass_4), "778899";
        echo "</br>";

        echo strtoupper($Pass_4), "778899.";
        echo "</br>";

        echo strtolower($Pass_4), "789789";
        echo "</br>";

        echo strtolower($Pass_4), "789789.";
        echo "</br>";

        echo strtoupper($Pass_4), "789789";
        echo "</br>";

        echo strtoupper($Pass_4), "789789.";
        echo "</br>";

        echo strtolower($Pass_4), "321321";
        echo "</br>";

        echo strtolower($Pass_4), "321321.";
        echo "</br>";

        echo strtoupper($Pass_4), "321321";
        echo "</br>";

        echo strtoupper($Pass_4), "321321.";
        echo "</br>";

        echo strtolower($Pass_4), "520";
        echo "</br>";

        echo strtolower($Pass_4), "520.";
        echo "</br>";
        echo strtoupper($Pass_4), "520";
        echo "</br>";

        echo strtoupper($Pass_4), "520.";
        echo "</br>";

        echo strtolower($Pass_4), "1314";
        echo "</br>";
		
		
		/*自己增加*/
		echo ucfirst($Pass_4), "520";
        echo "</br>";
		echo "520.",ucfirst($Pass_4);
        echo "</br>";
		echo "520",ucfirst($Pass_4);
        echo "</br>";
		echo ucfirst($Pass_4), "520.";
        echo "</br>";
		echo strtolower($Pass_4), ".com";
        echo "</br>";
		echo "123",strtolower($Pass_4);
        echo "</br>";
		echo strtolower($Pass_4), ".123";
        echo "</br>";
		echo strtolower($Pass_4), "123!@#";
        echo "</br>";
		echo strtolower($Pass_4), "abc";
        echo "</br>";
		echo strtoupper($Pass_4), "abc";

        echo "</br>";
		echo ucfirst($Pass_4), "abc";
        echo "</br>";
		echo strtolower($Pass_4), "ok";
        echo "</br>";
		echo strtoupper($Pass_4), "ok";
        echo "</br>";
		echo ucfirst($Pass_4), "ok";
        echo "</br>";
		echo strtolower($Pass_4), "521";
        echo "</br>";
		echo strtoupper($Pass_4), "521";
        echo "</br>";
		echo ucfirst($Pass_4), "521";
		echo "</br>";
		echo ucfirst($Pass_4), "2019";
		
        echo "</br>";
		echo '52',strtolower($Pass_4), "1314";
        echo "</br>";
		echo '52',strtoupper($Pass_4), "1314";
        echo "</br>";
		echo '52',ucfirst($Pass_4), "1314";
        echo "</br>";
		echo '520',strtolower($Pass_4), "1314";
        echo "</br>";
		echo '520',strtoupper($Pass_4), "1314";
        echo "</br>";
		echo '520',ucfirst($Pass_4), "1314";
        echo "</br>";
		echo '521',strtolower($Pass_4), "1314";
        echo "</br>";
		echo '521',strtoupper($Pass_4), "1314";
        echo "</br>";
		echo '521',ucfirst($Pass_4), "1314";
        echo "</br>";
		echo 'woai',strtolower($Pass_4), "1314";
        echo "</br>";
		echo 'woai',strtoupper($Pass_4), "1314";
        echo "</br>";
		echo 'woai',ucfirst($Pass_4), "1314";
        echo "</br>";
		echo strtolower($Pass_4), "211314";
        echo "</br>";
		echo strtoupper($Pass_4), "211314";
        echo "</br>";
		echo ucfirst($Pass_4), "211314";
        echo "</br>";	

        echo strtolower($Pass_4), "woaini1314";
        echo "</br>";   
        echo "woaini1314",strtolower($Pass_4);
        echo "</br>"; 
		echo strtolower($Pass_4), "abc123";
        echo "</br>";
		echo strtolower($Pass_4), "!@#123";
        echo "</br>";
		echo strtolower($Pass_4), ".!@#";
        echo "</br>";
		echo strtolower($Pass_4), ".666";
        echo "</br>";
		echo strtolower($Pass_4), "@123";
        echo "</br>";
		echo strtolower($Pass_4), "@2019";
        echo "</br>";
		echo strtolower($Pass_4), "2020";
        echo "</br>";
		echo strtolower($Pass_4), "@2020";
        echo "</br>";
		echo "2019",strtolower($Pass_4);
        echo "</br>";
		echo "2020",strtolower($Pass_4);
        echo "</br>";
		echo strtolower($Pass_4), "!123";
        echo "</br>";
		echo strtolower($Pass_4), "123!";
        echo "</br>";
		echo "123",ucfirst($Pass_4);
        echo "</br>";
		echo ucfirst($Pass_4), ".123";
        echo "</br>";
		echo ucfirst($Pass_4), "123!@#";
        echo "</br>";
		echo ucfirst($Pass_4), "!@#123";
        echo "</br>";
		echo ucfirst($Pass_4), ".!@#";
        echo "</br>";
		echo ucfirst($Pass_4), ".666";
        echo "</br>";
		echo ucfirst($Pass_4), "@123";
        echo "</br>";
		echo ucfirst($Pass_4), "@2019";
        echo "</br>";
		echo ucfirst($Pass_4), "2020";
        echo "</br>";
		echo ucfirst($Pass_4), "@2020";
        echo "</br>";
		echo "2019",ucfirst($Pass_4);
        echo "</br>";
		echo "2020",ucfirst($Pass_4);
        echo "</br>";
		echo ucfirst($Pass_4), "!123";
        echo "</br>";
		echo ucfirst($Pass_4), "123!";
        echo "</br>";
		echo "123",strtoupper($Pass_4);
        echo "</br>";
		echo strtoupper($Pass_4), ".123";
        echo "</br>";
		echo strtoupper($Pass_4), "123!@#";
        echo "</br>";
		echo strtoupper($Pass_4), "!@#123";
        echo "</br>";
		echo strtoupper($Pass_4), ".!@#";
        echo "</br>";
		echo strtoupper($Pass_4), ".666";
        echo "</br>";
		echo strtoupper($Pass_4), ".123456";
        echo "</br>";
		echo strtoupper($Pass_4), "@123456";
        echo "</br>";
		echo strtoupper($Pass_4), "@123";
        echo "</br>";
		echo strtoupper($Pass_4), "@2019";
        echo "</br>";
		echo strtoupper($Pass_4), "2020";
        echo "</br>";
		echo strtoupper($Pass_4), "@2020";
        echo "</br>";
		echo "2019",strtoupper($Pass_4);
        echo "</br>";
		echo "2020",strtoupper($Pass_4);
        echo "</br>";
		echo strtoupper($Pass_4), "!123";
        echo "</br>";
		echo strtoupper($Pass_4), "123!";
        echo "</br>";
		echo strtoupper($Pass_4), "!@#2019";
        echo "</br>";
		echo strtolower($Pass_4), "!@#2019";
        echo "</br>";
        echo strtolower($Pass_4), "admin";
        echo "</br>";
        echo "admin", strtolower($Pass_4);
        echo "</br>";
		echo ucfirst($Pass_4), "!@#2019";
        echo "</br>";
		echo strtoupper($Pass_4), "2019!@#";
        echo "</br>";
		echo strtolower($Pass_4), "2019!@#";
        echo "</br>";
		echo ucfirst($Pass_4), "2019!@#";
        echo "</br>";
		echo strtoupper($Pass_4), "!@#2020";
        echo "</br>";
		echo strtolower($Pass_4), "!@#2020";
        echo "</br>";
		echo ucfirst($Pass_4), "!@#2020";
        echo "</br>";
		echo strtoupper($Pass_4), "2020!@#";
        echo "</br>";
		echo strtolower($Pass_4), "2020!@#";
        echo "</br>";
		echo ucfirst($Pass_4), "2020!@#";
        echo "</br>";
		echo strtoupper($Pass_4), ".2019";
        echo "</br>";
		echo strtolower($Pass_4), ".2019";
        echo "</br>";
		echo ucfirst($Pass_4), ".2019";
        echo "</br>";
		echo strtoupper($Pass_4), "2019.";
        echo "</br>";
		echo strtolower($Pass_4), "2019.";
        echo "</br>";
		echo ucfirst($Pass_4), "2019.";
		echo "</br>";
		echo strtoupper($Pass_4), ".2020";
        echo "</br>";
		echo strtolower($Pass_4), ".2020";
        echo "</br>";
		echo ucfirst($Pass_4), ".2020";
        echo "</br>";
		echo strtoupper($Pass_4), "2020.";
        echo "</br>";
		echo strtolower($Pass_4), "2020.";
        echo "</br>";
		echo ucfirst($Pass_4), "888.";
        echo "</br>";
		echo strtoupper($Pass_4), ".888";
        echo "</br>";
		echo strtolower($Pass_4), ".888";
        echo "</br>";
		echo ucfirst($Pass_4), ".888";
        echo "</br>";
		echo strtoupper($Pass_4), "888.";
        echo "</br>";
		echo strtolower($Pass_4), "888.";
        echo "</br>";
		echo ucfirst($Pass_4), "888.";
	    echo "</br>";
		echo ucfirst($Pass_4), "666!@#";
        echo "</br>";
		echo strtoupper($Pass_4), "!@#666";
        echo "</br>";
		echo strtolower($Pass_4), "!@#666";
        echo "</br>";
		echo ucfirst($Pass_4), "!@#666";
        echo "</br>";
		echo strtoupper($Pass_4), "666!@#";
        echo "</br>";
		echo strtolower($Pass_4), "666!@#";
        echo "</br>";
		echo ucfirst($Pass_4), "666!@#";
	    echo "</br>";
		echo ucfirst($Pass_4), "666.";
        echo "</br>";
		echo strtoupper($Pass_4), ".666";
        echo "</br>";
		echo strtolower($Pass_4), ".666";
        echo "</br>";
		echo ucfirst($Pass_4), ".666";
        echo "</br>";
		echo strtoupper($Pass_4), "666.";
        echo "</br>";
		echo strtolower($Pass_4), "666.";
        echo "</br>";
		echo ucfirst($Pass_4), "666.";
	    echo "</br>";
		echo strtoupper($Pass_4), "@)!(";
        echo "</br>";
		echo strtolower($Pass_4), "@)!(";
        echo "</br>";
		echo ucfirst($Pass_4), "@)!(";
	    echo "</br>";
		echo strtoupper($Pass_4), "@)@)";
        echo "</br>";
		echo strtolower($Pass_4), "@)@)";
        echo "</br>";
		echo ucfirst($Pass_4), "@)@)";
	    echo "</br>";
		echo strtoupper($Pass_4), "!!!";
        echo "</br>";
		echo strtolower($Pass_4), "!!!";
        echo "</br>";
		echo ucfirst($Pass_4), "!!!";
	    echo "</br>";
		echo strtoupper($Pass_4), "@@";
        echo "</br>";
		echo strtolower($Pass_4), "@@";
        echo "</br>";
		echo ucfirst($Pass_4), "@@";
	    echo "</br>";
		echo ucfirst($Pass_4), "666!";
	    echo "</br>";
		echo ucfirst($Pass_4), "888!";
        echo "</br>";
		echo strtoupper($Pass_4), "!888";
        echo "</br>";
		echo strtolower($Pass_4), "!888";
        echo "</br>";
		echo ucfirst($Pass_4), "!888";
        echo "</br>";
		echo strtoupper($Pass_4), "888!";
        echo "</br>";
		echo strtolower($Pass_4), "888!";
        echo "</br>";
		echo ucfirst($Pass_4), "888!";
        echo "</br>";
		echo ucfirst($Pass_4), "888@";
        echo "</br>";
		echo strtoupper($Pass_4), "@888";
        echo "</br>";
		echo strtolower($Pass_4), "@888";
        echo "</br>";
		echo ucfirst($Pass_4), "@888";
        echo "</br>";
		echo strtoupper($Pass_4), "888@";
        echo "</br>";
		echo strtolower($Pass_4), "888@";
        echo "</br>";
		echo ucfirst($Pass_4), "888@";
	    echo "</br>";
		echo strtoupper($Pass_4), "!666";
        echo "</br>";
		echo strtolower($Pass_4), "!666";
        echo "</br>";
		echo ucfirst($Pass_4), "!666";
        echo "</br>";
		echo strtoupper($Pass_4), "666!";
        echo "</br>";
		echo strtolower($Pass_4), "666!";
        echo "</br>";
		echo ucfirst($Pass_4), "666!";
	    echo "</br>";
		echo ucfirst($Pass_4), "888!@#";
        echo "</br>";
		echo strtoupper($Pass_4), "!@#888";
        echo "</br>";
		echo strtolower($Pass_4), "!@#888";
        echo "</br>";
		echo ucfirst($Pass_4), "!@#888";
        echo "</br>";
		echo strtoupper($Pass_4), "888!@#";
        echo "</br>";
		echo strtolower($Pass_4), "888!@#";
        echo "</br>";
		echo ucfirst($Pass_4), "888!@#";
	    echo "</br>";
		/*自己增加的结束*/
		
		
		
        echo strtolower($Pass_4), "1314.";
        echo "</br>";

        echo strtoupper($Pass_4), "1314";
        echo "</br>";

        echo strtoupper($Pass_4), "1314.";
        echo "</br>";
		
		echo strtolower($Pass_4), "admin";
        echo "</br>";

        echo strtolower($Pass_4), "admin.";
        echo "</br>";

        echo strtoupper($Pass_4), "admin";
        echo "</br>";

        echo strtoupper($Pass_4), "admin.";
        echo "</br>";
		
		echo strtolower($Pass_4), ".admin";
        echo "</br>";

        echo strtolower($Pass_4), "_admin";
        echo "</br>";

        echo strtoupper($Pass_4), ".admin";
        echo "</br>";

        echo strtoupper($Pass_4), "_admin.";
        echo "</br>";
		
		echo strtolower($Pass_4), "!admin";
        echo "</br>";

        echo strtolower($Pass_4), "!@#admin.";
        echo "</br>";

        echo strtoupper($Pass_4), ".ADMIN";
        echo "</br>";

        echo strtoupper($Pass_4), "_ADMIN";
        echo "</br>";
		echo strtolower($Pass_4), "admin!";
        echo "</br>";

        echo strtolower($Pass_4), "admin!@#";
        echo "</br>";

		echo strtolower($Pass_4), "!";
        echo "</br>";

        echo strtolower($Pass_4), "!@#";
		echo "</br>";
		echo strtolower($Pass_4), "!@#$%";
        echo "</br>";

        echo strtolower($Pass_4), "!@#$%^";
        echo "</br>";

        echo strtoupper($Pass_4), "!@#$%";
        echo "</br>";

        echo strtoupper($Pass_4), "!@#$%^";
        echo "</br>";
		
		echo strtolower($Pass_4), "1qaz";
        echo "</br>";

        echo strtolower($Pass_4), "!QAZ";
        echo "</br>";

        echo strtoupper($Pass_4), "1qaz";
        echo "</br>";

        echo strtoupper($Pass_4), "!QAZ";
        echo "</br>";
		
		
		echo strtoupper($Pass_4), "ADMIN";
        echo "</br>";

        echo strtoupper($Pass_4), "ADMIN.";
        echo "</br>";

        echo strtolower($Pass_4), "5201314";
        echo "</br>";

        echo strtolower($Pass_4), "5201314.";
        echo "</br>";

        echo strtoupper($Pass_4), "5201314";
        echo "</br>";

        echo strtoupper($Pass_4), "5201314.";
        echo "</br>";

        echo strtolower($Pass_4), "1314520";
        echo "</br>";

        echo strtolower($Pass_4), "1314520.";
        echo "</br>";

        echo strtoupper($Pass_4), "1314520";
        echo "</br>";

        echo strtoupper($Pass_4), "1314520.";
        echo "</br>";

        echo strtolower($Pass_4), "147369";
        echo "</br>";

        echo strtolower($Pass_4), "147369.";
        echo "</br>";

        echo strtoupper($Pass_4), "147369";
        echo "</br>";

        echo strtoupper($Pass_4), "147369.";
        echo "</br>";

        echo strtolower($Pass_4), "258";
        echo "</br>";

        echo strtolower($Pass_4), "258.";
        echo "</br>";

        echo strtoupper($Pass_4), "258";
        echo "</br>";

        echo strtoupper($Pass_4), "258.";
        echo "</br>";

        echo strtolower($Pass_4), "147";
        echo "</br>";

        echo strtolower($Pass_4), "147.";
        echo "</br>";

        echo strtoupper($Pass_4), "147";
        echo "</br>";

        echo strtoupper($Pass_4), "147.";
        echo "</br>";

        echo strtolower($Pass_4), "456";
        echo "</br>";

        echo strtolower($Pass_4), "456.";
        echo "</br>";

        echo strtoupper($Pass_4), "456";
        echo "</br>";

        echo strtoupper($Pass_4), "456.";
        echo "</br>";

        echo strtolower($Pass_4), "789";
        echo "</br>";

        echo strtolower($Pass_4), "789.";
        echo "</br>";

        echo strtoupper($Pass_4), "789";
        echo "</br>";

        echo strtoupper($Pass_4), "789.";
        echo "</br>";

        echo strtolower($Pass_4), "147258369";
        echo "</br>";

        echo strtolower($Pass_4), "147258369.";
        echo "</br>";

        echo strtoupper($Pass_4), "147258369";
        echo "</br>";

        echo strtoupper($Pass_4), "147258369.";
        echo "</br>";

        echo strtolower($Pass_4), "111222";
        echo "</br>";

        echo strtolower($Pass_4), "111222.";
        echo "</br>";

        echo strtoupper($Pass_4), "111222";
        echo "</br>";

        echo strtoupper($Pass_4), "111222.";
        echo "</br>";

        echo strtolower($Pass_4), "1";
        echo "</br>";

        echo strtolower($Pass_4), "1.";
        echo "</br>";

        echo strtoupper($Pass_4), "1";
        echo "</br>";

        echo strtoupper($Pass_4), "1.";
        echo "</br>";

        echo strtolower($Pass_4), "12";
        echo "</br>";

        echo strtolower($Pass_4), "12.";
        echo "</br>";

        echo strtoupper($Pass_4), "12";
        echo "</br>";

        echo strtoupper($Pass_4), "12.";
        echo "</br>";



        echo strtolower($Pass_4), "123.";
        echo "</br>";

        echo strtoupper($Pass_4), "123";
        echo "</br>";

        echo strtoupper($Pass_4), "123.";
        echo "</br>";

        echo strtolower($Pass_4), "1234";
        echo "</br>";

        echo strtolower($Pass_4), "1234.";
        echo "</br>";

        echo strtoupper($Pass_4), "1234";
        echo "</br>";

        echo strtoupper($Pass_4), "1234.";
        echo "</br>";

        echo strtolower($Pass_4), "123456";
        echo "</br>";

        echo strtolower($Pass_4), "123456.";
        echo "</br>";

        echo strtoupper($Pass_4), "123456";
        echo "</br>";

        echo strtoupper($Pass_4), "123456.";
        echo "</br>";

        echo strtolower($Pass_4), "1234567";
        echo "</br>";

        echo strtolower($Pass_4), "1234567.";
        echo "</br>";

        echo strtoupper($Pass_4), "1234567";
        echo "</br>";

        echo strtoupper($Pass_4), "1234567.";
        echo "</br>";

        echo strtolower($Pass_4), "12345678";
        echo "</br>";

        echo strtolower($Pass_4), "12345678.";
        echo "</br>";

        echo strtoupper($Pass_4), "12345678";
        echo "</br>";

        echo strtoupper($Pass_4), "12345678.";
        echo "</br>";

        echo strtolower($Pass_4), "123456789";
        echo "</br>";

        echo strtolower($Pass_4), "123456789.";
        echo "</br>";

        echo strtoupper($Pass_4), "123456789";
        echo "</br>";

        echo strtoupper($Pass_4), "123456789.";
        echo "</br>";

        echo strtolower($Pass_4), "987654321";
        echo "</br>";

        echo strtolower($Pass_4), "978654321.";
        echo "</br>";

        echo strtoupper($Pass_4), "978654321";
        echo "</br>";

        echo strtoupper($Pass_4), "978654321.";
        echo "</br>";

        echo strtolower($Pass_4), "87654321";
        echo "</br>";

        echo strtolower($Pass_4), "78654321.";
        echo "</br>";

        echo strtoupper($Pass_4), "78654321";
        echo "</br>";

        echo strtoupper($Pass_4), "78654321.";
        echo "</br>";

        echo strtolower($Pass_4), "7654321";
        echo "</br>";

        echo strtolower($Pass_4), "8654321.";
        echo "</br>";

        echo strtoupper($Pass_4), "8654321";
        echo "</br>";

        echo strtoupper($Pass_4), "8654321.";
        echo "</br>";

        echo strtolower($Pass_4), "654321";
        echo "</br>";

        echo strtolower($Pass_4), "654321.";
        echo "</br>";

        echo strtoupper($Pass_4), "654321";
        echo "</br>";

        echo strtoupper($Pass_4), "654321.";
        echo "</br>";

        echo strtolower($Pass_4), "54321";
        echo "</br>";

        echo strtolower($Pass_4), "54321.";
        echo "</br>";

        echo strtoupper($Pass_4), "54321";
        echo "</br>";

        echo strtoupper($Pass_4), "54321.";
        echo "</br>";

        echo strtolower($Pass_4), "4321";
        echo "</br>";

        echo strtolower($Pass_4), "4321.";
        echo "</br>";

        echo strtoupper($Pass_4), "4321";
        echo "</br>";

        echo strtoupper($Pass_4), "4321.";
        echo "</br>";

        echo strtolower($Pass_4), "321";
        echo "</br>";

        echo strtolower($Pass_4), "321.";
        echo "</br>";

        echo strtoupper($Pass_4), "321";
        echo "</br>";

        echo strtoupper($Pass_4), "321.";
        echo "</br>";

        echo strtolower($Pass_4), "21";
        echo "</br>";

        echo strtolower($Pass_4), "21.";
        echo "</br>";

        echo strtoupper($Pass_4), "21";
        echo "</br>";

        echo strtoupper($Pass_4), "21.";
        echo "</br>";

        echo strtolower($Pass_4), "11";
        echo "</br>";

        echo strtolower($Pass_4), "11.";
        echo "</br>";

        echo strtoupper($Pass_4), "11";
        echo "</br>";

        echo strtoupper($Pass_4), "11.";
        echo "</br>";

        echo strtolower($Pass_4), "111";
        echo "</br>";

        echo strtolower($Pass_4), "111.";
        echo "</br>";

        echo strtoupper($Pass_4), "111";
        echo "</br>";

        echo strtoupper($Pass_4), "111.";
        echo "</br>";

        echo strtolower($Pass_4), "1111";
        echo "</br>";

        echo strtolower($Pass_4), "1111.";
        echo "</br>";

        echo strtoupper($Pass_4), "1111";
        echo "</br>";

        echo strtoupper($Pass_4), "1111.";
        echo "</br>";

        echo strtolower($Pass_4), "11111";
        echo "</br>";

        echo strtolower($Pass_4), "11111.";
        echo "</br>";

        echo strtoupper($Pass_4), "11111";
        echo "</br>";

        echo strtoupper($Pass_4), "11111.";
        echo "</br>";

        echo strtolower($Pass_4), "111111";
        echo "</br>";

        echo strtolower($Pass_4), "111111.";
        echo "</br>";

        echo strtoupper($Pass_4), "111111";
        echo "</br>";

        echo strtoupper($Pass_4), "111111.";
        echo "</br>";

        echo strtolower($Pass_4), "1111111";
        echo "</br>";

        echo strtolower($Pass_4), "1111111.";
        echo "</br>";

        echo strtoupper($Pass_4), "1111111";
        echo "</br>";

        echo strtoupper($Pass_4), "1111111.";
        echo "</br>";

        echo strtolower($Pass_4), "11111111";
        echo "</br>";

        echo strtolower($Pass_4), "11111111.";
        echo "</br>";

        echo strtoupper($Pass_4), "11111111";
        echo "</br>";

        echo strtoupper($Pass_4), "11111111.";
        echo "</br>";

        echo strtolower($Pass_4), "2";
        echo "</br>";

        echo strtolower($Pass_4), "2.";
        echo "</br>";

        echo strtoupper($Pass_4), "2";
        echo "</br>";

        echo strtoupper($Pass_4), "2.";
        echo "</br>";

        echo strtolower($Pass_4), "22";
        echo "</br>";

        echo strtolower($Pass_4), "22.";
        echo "</br>";

        echo strtoupper($Pass_4), "22";
        echo "</br>";

        echo strtoupper($Pass_4), "22.";
        echo "</br>";

        echo strtolower($Pass_4), "222";
        echo "</br>";

        echo strtolower($Pass_4), "222.";
        echo "</br>";

        echo strtoupper($Pass_4), "222";
        echo "</br>";

        echo strtoupper($Pass_4), "222.";
        echo "</br>";

        echo strtolower($Pass_4), "2222";
        echo "</br>";

        echo strtolower($Pass_4), "2222.";
        echo "</br>";

        echo strtoupper($Pass_4), "2222";
        echo "</br>";

        echo strtoupper($Pass_4), "2222.";
        echo "</br>";

        echo strtolower($Pass_4), "22222";
        echo "</br>";

        echo strtolower($Pass_4), "22222.";
        echo "</br>";

        echo strtoupper($Pass_4), "22222";
        echo "</br>";

        echo strtoupper($Pass_4), "22222.";
        echo "</br>";

        echo strtolower($Pass_4), "222222";
        echo "</br>";

        echo strtolower($Pass_4), "222222.";
        echo "</br>";

        echo strtoupper($Pass_4), "222222";
        echo "</br>";

        echo strtoupper($Pass_4), "222222.";
        echo "</br>";

        echo strtolower($Pass_4), "2222222";
        echo "</br>";

        echo strtolower($Pass_4), "2222222.";
        echo "</br>";

        echo strtoupper($Pass_4), "2222222";
        echo "</br>";

        echo strtoupper($Pass_4), "2222222.";
        echo "</br>";

        echo strtolower($Pass_4), "22222222";
        echo "</br>";

        echo strtolower($Pass_4), "22222222.";
        echo "</br>";

        echo strtoupper($Pass_4), "22222222";
        echo "</br>";

        echo strtoupper($Pass_4), "22222222.";
        echo "</br>";

        echo strtolower($Pass_4), "33";
        echo "</br>";

        echo strtolower($Pass_4), "33.";
        echo "</br>";

        echo strtoupper($Pass_4), "33";
        echo "</br>";

        echo strtoupper($Pass_4), "33.";
        echo "</br>";

        echo strtolower($Pass_4), "333";
        echo "</br>";

        echo strtolower($Pass_4), "333.";
        echo "</br>";

        echo strtoupper($Pass_4), "333";
        echo "</br>";

        echo strtoupper($Pass_4), "333.";
        echo "</br>";

        echo strtolower($Pass_4), "3333";
        echo "</br>";

        echo strtolower($Pass_4), "3333.";
        echo "</br>";

        echo strtoupper($Pass_4), "3333";
        echo "</br>";

        echo strtoupper($Pass_4), "3333.";
        echo "</br>";

        echo strtolower($Pass_4), "33333";
        echo "</br>";

        echo strtolower($Pass_4), "33333.";
        echo "</br>";

        echo strtoupper($Pass_4), "33333";
        echo "</br>";

        echo strtoupper($Pass_4), "33333.";
        echo "</br>";

        echo strtolower($Pass_4), "333333";
        echo "</br>";

        echo strtolower($Pass_4), "333333.";
        echo "</br>";

        echo strtoupper($Pass_4), "333333";
        echo "</br>";

        echo strtoupper($Pass_4), "333333.";
        echo "</br>";

        echo strtolower($Pass_4), "3333333";
        echo "</br>";

        echo strtolower($Pass_4), "3333333.";
        echo "</br>";

        echo strtoupper($Pass_4), "3333333";
        echo "</br>";

        echo strtoupper($Pass_4), "3333333.";
        echo "</br>";

        echo strtolower($Pass_4), "33333333";
        echo "</br>";

        echo strtolower($Pass_4), "33333333.";
        echo "</br>";

        echo strtoupper($Pass_4), "33333333";
        echo "</br>";

        echo strtoupper($Pass_4), "33333333.";
        echo "</br>";

        echo strtolower($Pass_4), "44";
        echo "</br>";

        echo strtolower($Pass_4), "44.";
        echo "</br>";

        echo strtoupper($Pass_4), "44";
        echo "</br>";

        echo strtoupper($Pass_4), "44.";
        echo "</br>";

        echo strtolower($Pass_4), "444";
        echo "</br>";

        echo strtolower($Pass_4), "444.";
        echo "</br>";

        echo strtoupper($Pass_4), "444";
        echo "</br>";

        echo strtoupper($Pass_4), "444.";
        echo "</br>";

        echo strtolower($Pass_4), "4444";
        echo "</br>";

        echo strtolower($Pass_4), "4444.";
        echo "</br>";

        echo strtoupper($Pass_4), "4444";
        echo "</br>";

        echo strtoupper($Pass_4), "4444.";
        echo "</br>";

        echo strtolower($Pass_4), "44444";
        echo "</br>";

        echo strtolower($Pass_4), "44444.";
        echo "</br>";

        echo strtoupper($Pass_4), "44444";
        echo "</br>";

        echo strtoupper($Pass_4), "44444.";
        echo "</br>";

        echo strtolower($Pass_4), "444444";
        echo "</br>";

        echo strtolower($Pass_4), "444444.";
        echo "</br>";

        echo strtoupper($Pass_4), "444444";
        echo "</br>";

        echo strtoupper($Pass_4), "444444.";
        echo "</br>";

        echo strtolower($Pass_4), "4444444";
        echo "</br>";

        echo strtolower($Pass_4), "4444444.";
        echo "</br>";

        echo strtoupper($Pass_4), "4444444";
        echo "</br>";

        echo strtoupper($Pass_4), "4444444.";
        echo "</br>";

        echo strtolower($Pass_4), "44444444";
        echo "</br>";

        echo strtolower($Pass_4), "44444444.";
        echo "</br>";

        echo strtoupper($Pass_4), "44444444";
        echo "</br>";

        echo strtoupper($Pass_4), "44444444.";
        echo "</br>";

        echo strtolower($Pass_4), "55";
        echo "</br>";

        echo strtolower($Pass_4), "55.";
        echo "</br>";

        echo strtoupper($Pass_4), "55";
        echo "</br>";

        echo strtoupper($Pass_4), "55.";
        echo "</br>";

        echo strtolower($Pass_4), "555";
        echo "</br>";

        echo strtolower($Pass_4), "555.";
        echo "</br>";

        echo strtoupper($Pass_4), "555";
        echo "</br>";

        echo strtoupper($Pass_4), "555.";
        echo "</br>";

        echo strtolower($Pass_4), "5555";
        echo "</br>";

        echo strtolower($Pass_4), "5555.";
        echo "</br>";

        echo strtoupper($Pass_4), "5555";
        echo "</br>";

        echo strtoupper($Pass_4), "5555.";
        echo "</br>";

        echo strtolower($Pass_4), "55555";
        echo "</br>";

        echo strtolower($Pass_4), "55555.";
        echo "</br>";

        echo strtoupper($Pass_4), "55555";
        echo "</br>";

        echo strtoupper($Pass_4), "55555.";
        echo "</br>";

        echo strtolower($Pass_4), "555555";
        echo "</br>";

        echo strtolower($Pass_4), "555555.";
        echo "</br>";

        echo strtoupper($Pass_4), "555555";
        echo "</br>";

        echo strtoupper($Pass_4), "555555.";
        echo "</br>";

        echo strtolower($Pass_4), "5555555";
        echo "</br>";

        echo strtolower($Pass_4), "5555555.";
        echo "</br>";

        echo strtoupper($Pass_4), "5555555";
        echo "</br>";

        echo strtoupper($Pass_4), "5555555.";
        echo "</br>";

        echo strtolower($Pass_4), "55555555";
        echo "</br>";

        echo strtolower($Pass_4), "55555555.";
        echo "</br>";

        echo strtoupper($Pass_4), "55555555";
        echo "</br>";

        echo strtoupper($Pass_4), "55555555.";
        echo "</br>";

        echo strtolower($Pass_4), "66";
        echo "</br>";

        echo strtolower($Pass_4), "66.";
        echo "</br>";

        echo strtoupper($Pass_4), "66";
        echo "</br>";

        echo strtoupper($Pass_4), "66.";
        echo "</br>";

        echo strtolower($Pass_4), "666";
        echo "</br>";

        echo strtolower($Pass_4), "666.";
        echo "</br>";

        echo strtoupper($Pass_4), "666";
        echo "</br>";

        echo strtoupper($Pass_4), "666.";
        echo "</br>";

        echo strtolower($Pass_4), "6666";
        echo "</br>";

        echo strtolower($Pass_4), "6666.";
        echo "</br>";

        echo strtoupper($Pass_4), "6666";
        echo "</br>";

        echo strtoupper($Pass_4), "6666.";
        echo "</br>";

        echo strtolower($Pass_4), "66666";
        echo "</br>";

        echo strtolower($Pass_4), "66666.";
        echo "</br>";

        echo strtoupper($Pass_4), "66666";
        echo "</br>";

        echo strtoupper($Pass_4), "66666.";
        echo "</br>";

        echo strtolower($Pass_4), "666666";
        echo "</br>";

        echo strtolower($Pass_4), "666666.";
        echo "</br>";

        echo strtoupper($Pass_4), "666666";
        echo "</br>";

        echo strtoupper($Pass_4), "666666.";
        echo "</br>";

        echo strtolower($Pass_4), "6666666";
        echo "</br>";

        echo strtolower($Pass_4), "6666666.";
        echo "</br>";

        echo strtoupper($Pass_4), "6666666";
        echo "</br>";

        echo strtoupper($Pass_4), "6666666.";
        echo "</br>";

        echo strtolower($Pass_4), "66666666";
        echo "</br>";

        echo strtolower($Pass_4), "66666666.";
        echo "</br>";

        echo strtoupper($Pass_4), "66666666";
        echo "</br>";

        echo strtoupper($Pass_4), "66666666.";
        echo "</br>";

        echo strtolower($Pass_4), "77";
        echo "</br>";

        echo strtolower($Pass_4), "77.";
        echo "</br>";

        echo strtoupper($Pass_4), "77";
        echo "</br>";

        echo strtoupper($Pass_4), "77.";
        echo "</br>";

        echo strtolower($Pass_4), "777";
        echo "</br>";

        echo strtolower($Pass_4), "777.";
        echo "</br>";

        echo strtoupper($Pass_4), "777";
        echo "</br>";

        echo strtoupper($Pass_4), "777.";
        echo "</br>";

        echo strtolower($Pass_4), "7777";
        echo "</br>";

        echo strtolower($Pass_4), "7777.";
        echo "</br>";

        echo strtoupper($Pass_4), "7777";
        echo "</br>";

        echo strtoupper($Pass_4), "7777.";
        echo "</br>";

        echo strtolower($Pass_4), "77777";
        echo "</br>";

        echo strtolower($Pass_4), "77777.";
        echo "</br>";

        echo strtoupper($Pass_4), "77777";
        echo "</br>";

        echo strtoupper($Pass_4), "77777.";
        echo "</br>";

        echo strtolower($Pass_4), "777777";
        echo "</br>";

        echo strtolower($Pass_4), "777777.";
        echo "</br>";

        echo strtoupper($Pass_4), "777777";
        echo "</br>";

        echo strtoupper($Pass_4), "777777.";
        echo "</br>";

        echo strtolower($Pass_4), "7777777";
        echo "</br>";

        echo strtolower($Pass_4), "7777777.";
        echo "</br>";

        echo strtoupper($Pass_4), "7777777";
        echo "</br>";

        echo strtoupper($Pass_4), "7777777.";
        echo "</br>";

        echo strtolower($Pass_4), "77777777";
        echo "</br>";

        echo strtolower($Pass_4), "77777777.";
        echo "</br>";

        echo strtoupper($Pass_4), "77777777";
        echo "</br>";

        echo strtoupper($Pass_4), "77777777.";
        echo "</br>";

        echo strtolower($Pass_4), "88";
        echo "</br>";

        echo strtolower($Pass_4), "88.";
        echo "</br>";

        echo strtoupper($Pass_4), "88";
        echo "</br>";

        echo strtoupper($Pass_4), "88.";
        echo "</br>";

        echo strtolower($Pass_4), "888";
        echo "</br>";

        echo strtolower($Pass_4), "888.";
        echo "</br>";

        echo strtoupper($Pass_4), "888";
        echo "</br>";

        echo strtoupper($Pass_4), "888.";
        echo "</br>";

        echo strtolower($Pass_4), "8888";
        echo "</br>";

        echo strtolower($Pass_4), "8888.";
        echo "</br>";

        echo strtoupper($Pass_4), "8888";
        echo "</br>";

        echo strtoupper($Pass_4), "8888.";
        echo "</br>";

        echo strtolower($Pass_4), "88888";
        echo "</br>";

        echo strtolower($Pass_4), "88888.";
        echo "</br>";

        echo strtoupper($Pass_4), "88888";
        echo "</br>";

        echo strtoupper($Pass_4), "88888.";
        echo "</br>";

        echo strtolower($Pass_4), "888888";
        echo "</br>";

        echo strtolower($Pass_4), "888888.";
        echo "</br>";

        echo strtoupper($Pass_4), "888888";
        echo "</br>";

        echo strtoupper($Pass_4), "888888.";
        echo "</br>";

        echo strtolower($Pass_4), "8888888";
        echo "</br>";

        echo strtolower($Pass_4), "8888888.";
        echo "</br>";

        echo strtoupper($Pass_4), "8888888";
        echo "</br>";

        echo strtoupper($Pass_4), "8888888.";
        echo "</br>";

        echo strtolower($Pass_4), "88888888";
        echo "</br>";

        echo strtolower($Pass_4), "88888888.";
        echo "</br>";

        echo strtoupper($Pass_4), "88888888";
        echo "</br>";

        echo strtoupper($Pass_4), "88888888.";
        echo "</br>";

        echo strtolower($Pass_4), "99";
        echo "</br>";

        echo strtolower($Pass_4), "99.";
        echo "</br>";

        echo strtoupper($Pass_4), "99";
        echo "</br>";

        echo strtoupper($Pass_4), "99.";
        echo "</br>";

        echo strtolower($Pass_4), "999";
        echo "</br>";

        echo strtolower($Pass_4), "999.";
        echo "</br>";

        echo strtoupper($Pass_4), "999";
        echo "</br>";

        echo strtoupper($Pass_4), "999.";
        echo "</br>";

        echo strtolower($Pass_4), "9999";
        echo "</br>";

        echo strtolower($Pass_4), "9999.";
        echo "</br>";

        echo strtoupper($Pass_4), "9999";
        echo "</br>";

        echo strtoupper($Pass_4), "9999.";
        echo "</br>";

        echo strtolower($Pass_4), "99999";
        echo "</br>";

        echo strtolower($Pass_4), "99999.";
        echo "</br>";

        echo strtoupper($Pass_4), "99999";
        echo "</br>";

        echo strtoupper($Pass_4), "99999.";
        echo "</br>";

        echo strtolower($Pass_4), "999999";
        echo "</br>";

        echo strtolower($Pass_4), "999999.";
        echo "</br>";

        echo strtoupper($Pass_4), "999999";
        echo "</br>";

        echo strtoupper($Pass_4), "999999.";
        echo "</br>";

        echo strtolower($Pass_4), "9999999";
        echo "</br>";

        echo strtolower($Pass_4), "9999999.";
        echo "</br>";

        echo strtoupper($Pass_4), "9999999";
        echo "</br>";

        echo strtoupper($Pass_4), "9999999.";
        echo "</br>";

        echo strtolower($Pass_4), "99999999";
        echo "</br>";

        echo strtolower($Pass_4), "99999999.";
        echo "</br>";

        echo strtoupper($Pass_4), "99999999";
        echo "</br>";

        echo strtoupper($Pass_4), "99999999.";
        echo "</br>";

        echo strtolower($Pass_4), "00";
        echo "</br>";

        echo strtolower($Pass_4), "00.";
        echo "</br>";

        echo strtoupper($Pass_4), "00";
        echo "</br>";

        echo strtoupper($Pass_4), "00.";
        echo "</br>";

        echo strtolower($Pass_4), "000";
        echo "</br>";

        echo strtolower($Pass_4), "000.";
        echo "</br>";

        echo strtoupper($Pass_4), "000";
        echo "</br>";

        echo strtoupper($Pass_4), "000.";
        echo "</br>";

        echo strtolower($Pass_4), "0000";
        echo "</br>";

        echo strtolower($Pass_4), "0000.";
        echo "</br>";

        echo strtoupper($Pass_4), "0000";
        echo "</br>";

        echo strtoupper($Pass_4), "0000.";
        echo "</br>";

        echo strtolower($Pass_4), "00000";
        echo "</br>";

        echo strtolower($Pass_4), "00000.";
        echo "</br>";

        echo strtoupper($Pass_4), "00000";
        echo "</br>";

        echo strtoupper($Pass_4), "00000.";
        echo "</br>";

        echo strtolower($Pass_4), "000000";
        echo "</br>";

        echo strtolower($Pass_4), "000000.";
        echo "</br>";

        echo strtoupper($Pass_4), "000000";
        echo "</br>";

        echo strtoupper($Pass_4), "000000.";
        echo "</br>";

        echo strtolower($Pass_4), "0000000";
        echo "</br>";

        echo strtolower($Pass_4), "0000000.";
        echo "</br>";

        echo strtoupper($Pass_4), "0000000";
        echo "</br>";

        echo strtoupper($Pass_4), "0000000.";
        echo "</br>";

        echo strtolower($Pass_4), "00000000";
        echo "</br>";

        echo strtolower($Pass_4), "00000000.";
        echo "</br>";

        echo strtoupper($Pass_4), "00000000";
        echo "</br>";

        echo strtoupper($Pass_4), "00000000.";
        echo "</br>";

        echo strtolower($Pass_4), "1997";
        echo "</br>";

        echo strtolower($Pass_4), "1997.";
        echo "</br>";

        echo strtoupper($Pass_4), "1997";
        echo "</br>";

        echo strtoupper($Pass_4), "1997.";
        echo "</br>";

        echo strtolower($Pass_4), "1998";
        echo "</br>";

        echo strtolower($Pass_4), "1998.";
        echo "</br>";

        echo strtoupper($Pass_4), "1998";
        echo "</br>";

        echo strtoupper($Pass_4), "1998.";
        echo "</br>";

        echo strtolower($Pass_4), "1999";
        echo "</br>";

        echo strtolower($Pass_4), "1999.";
        echo "</br>";

        echo strtoupper($Pass_4), "1999";
        echo "</br>";

        echo strtoupper($Pass_4), "1999.";
        echo "</br>";

        echo strtolower($Pass_4), "2000";
        echo "</br>";

        echo strtolower($Pass_4), "2000.";
        echo "</br>";

        echo strtoupper($Pass_4), "2000";
        echo "</br>";

        echo strtoupper($Pass_4), "2000.";
        echo "</br>";

        echo strtolower($Pass_4), "2001";
        echo "</br>";

        echo strtolower($Pass_4), "2001.";
        echo "</br>";

        echo strtoupper($Pass_4), "2001";
        echo "</br>";

        echo strtoupper($Pass_4), "2001.";
        echo "</br>";

        echo strtolower($Pass_4), "2002";
        echo "</br>";

        echo strtolower($Pass_4), "2002.";
        echo "</br>";

        echo strtoupper($Pass_4), "2002";
        echo "</br>";

        echo strtoupper($Pass_4), "2002.";
        echo "</br>";

        echo strtolower($Pass_4), "2003";
        echo "</br>";

        echo strtolower($Pass_4), "2003.";
        echo "</br>";

        echo strtoupper($Pass_4), "2003";
        echo "</br>";

        echo strtoupper($Pass_4), "2003.";
        echo "</br>";

        echo strtolower($Pass_4), "2004";
        echo "</br>";

        echo strtolower($Pass_4), "2004.";
        echo "</br>";

        echo strtoupper($Pass_4), "2004";
        echo "</br>";

        echo strtoupper($Pass_4), "2004.";
        echo "</br>";

        echo strtolower($Pass_4), "2005";
        echo "</br>";

        echo strtolower($Pass_4), "2005.";
        echo "</br>";

        echo strtoupper($Pass_4), "2005";
        echo "</br>";

        echo strtoupper($Pass_4), "2005.";
        echo "</br>";

        echo strtolower($Pass_4), "2006";
        echo "</br>";

        echo strtolower($Pass_4), "2006.";
        echo "</br>";

        echo strtoupper($Pass_4), "2006";
        echo "</br>";

        echo strtoupper($Pass_4), "2006.";
        echo "</br>";

        echo strtolower($Pass_4), "2007";
        echo "</br>";

        echo strtolower($Pass_4), "2007.";
        echo "</br>";

        echo strtoupper($Pass_4), "2007";
        echo "</br>";

        echo strtoupper($Pass_4), "2007.";
        echo "</br>";

        echo strtolower($Pass_4), "2008";
        echo "</br>";

        echo strtolower($Pass_4), "2008.";
        echo "</br>";

        echo strtoupper($Pass_4), "2008";
        echo "</br>";

        echo strtoupper($Pass_4), "2008.";
        echo "</br>";

        echo strtolower($Pass_4), "2009";
        echo "</br>";

        echo strtolower($Pass_4), "2009.";
        echo "</br>";

        echo strtoupper($Pass_4), "2009";
        echo "</br>";

        echo strtoupper($Pass_4), "2009.";
        echo "</br>";

        echo strtolower($Pass_4), "2010";
        echo "</br>";

        echo strtolower($Pass_4), "2010.";
        echo "</br>";

        echo strtoupper($Pass_4), "2010";
        echo "</br>";

        echo strtoupper($Pass_4), "2010.";
        echo "</br>";

        echo strtolower($Pass_4), "2011";
        echo "</br>";

        echo strtolower($Pass_4), "2011.";
        echo "</br>";

        echo strtoupper($Pass_4), "2011";
        echo "</br>";

        echo strtoupper($Pass_4), "2011.";
        echo "</br>";

        echo strtolower($Pass_4), "2012";
        echo "</br>";

        echo strtolower($Pass_4), "2012.";
        echo "</br>";

        echo strtoupper($Pass_4), "2012";
        echo "</br>";

        echo strtoupper($Pass_4), "2012.";
        echo "</br>";

        echo strtolower($Pass_4), "2013";
        echo "</br>";

        echo strtolower($Pass_4), "2013.";
        echo "</br>";

        echo strtoupper($Pass_4), "2013";
        echo "</br>";

        echo strtoupper($Pass_4), "2013.";
        echo "</br>";

        echo strtolower($Pass_4), "2014";
        echo "</br>";

        echo strtolower($Pass_4), "2014.";
        echo "</br>";

        echo strtoupper($Pass_4), "2014";
        echo "</br>";

        echo strtoupper($Pass_4), "2014.";
        echo "</br>";

        echo strtolower($Pass_4), "2015";
        echo "</br>";

        echo strtolower($Pass_4), "2015.";
        echo "</br>";

        echo strtoupper($Pass_4), "2015";
        echo "</br>";

        echo strtoupper($Pass_4), "2015.";
        echo "</br>";

        echo strtolower($Pass_4), "2016";
        echo "</br>";

        echo strtolower($Pass_4), "2016.";
        echo "</br>";

        echo strtoupper($Pass_4), "2016";
        echo "</br>";

        echo strtoupper($Pass_4), "2016.";
        echo "</br>";

        echo strtolower($Pass_4), "2017";
        echo "</br>";

        echo strtolower($Pass_4), "2017.";
        echo "</br>";

        echo strtoupper($Pass_4), "2017";
        echo "</br>";

        echo strtoupper($Pass_4), "2017.";
        echo "</br>";

        echo strtolower($Pass_4), "2018";
        echo "</br>";

        echo strtolower($Pass_4), "2018.";
        echo "</br>";

        echo strtoupper($Pass_4), "2018";
        echo "</br>";

        echo strtoupper($Pass_4), "2018.";
        echo "</br>";
		
		echo strtolower($Pass_4), "2019";
        echo "</br>";

        echo strtolower($Pass_4), "2019.";
        echo "</br>";

        echo strtoupper($Pass_4), "2019";
        echo "</br>";

        echo strtoupper($Pass_4), "2019.";
        echo "</br>";

    }

    if ($post_num == $null)
        echo "";
    else
        Pass_Attack_4($post_num);


    function pass_Attack_5($Pass_5 = "woaini")
    {

        echo "woaini", strtolower($Pass_5);
        echo "</br>";

        echo "woaini", strtolower($Pass_5), ".";
        echo "</br>";

        echo "WOAINI", strtoupper($Pass_5);
        echo "</br>";

        echo "WOAINI", strtoupper($Pass_5), ".";
        echo "</br>";

        echo "520", strtolower($Pass_5);
        echo "</br>";

        echo "520", strtolower($Pass_5), ".";
        echo "</br>";

        echo "520", strtoupper($Pass_5);
        echo "</br>";

        echo "520", strtoupper($Pass_5), ".";
        echo "</br>";

        echo strtolower($Pass_5), "lovewifejp";
        echo "</br>";

        echo strtolower($Pass_5), "lovewifejp.";
        echo "</br>";

        echo strtoupper($Pass_5), "LOVEWIFEJP";
        echo "</br>";

        echo strtoupper($Pass_5), "LOVEWIFEJP.";
        echo "</br>";

    }

    if ($post_ename == $null)
        echo "";
    else
        Pass_Attack_5($post_ename);
    if ($post_ename == $null)
        echo "";
    else
        Pass_Attack_4($post_ename);


    function pass_Attack_6($Pass_6 = "woaini")
    {

        echo "520", strtolower($Pass_6);
        echo "</br>";

        echo "520", strtolower($Pass_6), ".";
        echo "</br>";

        echo "520", strtoupper($Pass_6);
        echo "</br>";

        echo "520", strtoupper($Pass_6), ".";
        echo "</br>";

    }

    if ($post_username == $null)
        echo "";
    else
        Pass_Attack_6($post_username);
    if ($post_username == $null)
        echo "";
    else
        Pass_Attack_4($post_username);


    function pass_Attack_7($Pass_7 = "woaini")
    {

        echo "520", strtolower($Pass_7);
        echo "</br>";

        echo "520", strtolower($Pass_7), ".";
        echo "</br>";

        echo "520", strtoupper($Pass_7);
        echo "</br>";

        echo "520", strtoupper($Pass_7), ".";
        echo "</br>";

    }

    if ($post_email == $null)
        echo "";
    else
        Pass_Attack_7($post_email);
    if ($post_email == $null)
        echo "";
    else
        Pass_Attack_4($post_email);


    function pass_Attack_8($Pass_8 = "woaini")
    {
        echo "520", strtolower($Pass_8);
        echo "</br>";

        echo "520", strtolower($Pass_8), ".";
        echo "</br>";

        echo "5201314", strtolower($Pass_8);
        echo "</br>";

        echo "5201314", strtolower($Pass_8), ".";
        echo "</br>";

        echo "1314", strtolower($Pass_8);
        echo "</br>";

        echo "1314", strtolower($Pass_8), ".";
        echo "</br>";

        echo strtolower($Pass_8), "520";
        echo "</br>";
		

        echo strtolower($Pass_8), "520.";
        echo "</br>";

        echo strtolower($Pass_8), "5201314";
        echo "</br>";

        echo strtolower($Pass_8), "5201314.";
        echo "</br>";

        echo strtolower($Pass_8), "1314";
        echo "</br>";

        echo strtolower($Pass_8), "1314.";
        echo "</br>";

        echo strtolower($Pass_8), "loveu";
        echo "</br>";

        echo strtolower($Pass_8), "loveu.";
        echo "</br>";

        echo strtolower($Pass_8), "loveyou";
        echo "</br>";

        echo strtolower($Pass_8), "loveyou.";
        echo "</br>";

        echo strtoupper($Pass_8), "520";
        echo "</br>";

        echo strtoupper($Pass_8), "520.";
        echo "</br>";

        echo strtoupper($Pass_8), "5201314";
        echo "</br>";

        echo strtoupper($Pass_8), "5201314.";
        echo "</br>";

        echo strtoupper($Pass_8), "1314";
        echo "</br>";

        echo strtoupper($Pass_8), "1314.";
        echo "</br>";

        echo strtoupper($Pass_8), "LOVEU";
        echo "</br>";

        echo strtoupper($Pass_8), "LOVEU.";
        echo "</br>";

        echo strtoupper($Pass_8), "LOVEYOU";
        echo "</br>";

        echo strtoupper($Pass_8), "LOVEYOU.";
        echo "</br>";


    }

    if ($post_wifejp == $null)
        echo "";
    else
        Pass_Attack_8($post_wifejp);
    if ($post_wifeqp == $null)
        echo "";
    else
        Pass_Attack_8($post_wifeqp);
    if ($post_wifejp == $null)
        echo "";
    else
        Pass_Attack_4($post_wifejp);
    if ($post_wifeqp == $null)
        echo "";
    else
        Pass_Attack_4($post_wifeqp);


    function pass_Attack_9($Pass_9 = "woaini")
    {

        echo "a", strtolower($Pass_9);
        echo "</br>";

        echo "a", strtolower($Pass_9), ".";
        echo "</br>";

        echo "A", strtoupper($Pass_9);
        echo "</br>";

        echo "A", strtoupper($Pass_9), ".";
        echo "</br>";

        echo "qq", strtolower($Pass_9);
        echo "</br>";

        echo "qq", strtolower($Pass_9), ".";
        echo "</br>";

        echo "QQ", strtoupper($Pass_9);
        echo "</br>";

        echo "QQ", strtoupper($Pass_9), ".";
        echo "</br>";

        echo "yy", strtolower($Pass_9);
        echo "</br>";

        echo "yy", strtolower($Pass_9), ".";
        echo "</br>";

        echo "YY", strtoupper($Pass_9);
        echo "</br>";

        echo "YY", strtoupper($Pass_9), ".";
        echo "</br>";

        echo "aa", strtolower($Pass_9);
        echo "</br>";

        echo "aa", strtolower($Pass_9), ".";
        echo "</br>";

        echo "AA", strtoupper($Pass_9);
        echo "</br>";

        echo "abc", strtoupper($Pass_9), ".";
        echo "</br>";

        echo "abc", strtolower($Pass_9);
        echo "</br>";

        echo "abc", strtolower($Pass_9), ".";
        echo "</br>";

        echo "ABC", strtoupper($Pass_9);
        echo "</br>";

        echo "ABC", strtoupper($Pass_9), ".";
        echo "</br>";

        echo "qwer", strtolower($Pass_9);
        echo "</br>";

        echo "qwer", strtolower($Pass_9), ".";
        echo "</br>";

        echo "QWER", strtoupper($Pass_9);
        echo "</br>";

        echo "QWER", strtoupper($Pass_9), ".";
        echo "</br>";

        echo "woaini", strtolower($Pass_9);
        echo "</br>";

        echo "woaini", strtolower($Pass_9), ".";
        echo "</br>";

        echo "WOAINI", strtoupper($Pass_9);
        echo "</br>";

        echo "WOAINI", strtoupper($Pass_9), ".";
        echo "</br>";

    }

    if ($post_qq == $null)
        echo "";
    else
        Pass_Attack_9($post_qq);
    if ($post_tel == $null)
        echo "";
    else
        Pass_Attack_9($post_birth);
    if ($post_birth == $null)
        echo "";
    else
        Pass_Attack_9($post_birth);
	
?>

<?php

echo "123456.";
echo "</br>";
echo "a123456";
echo "</br>";
echo "a123456.";
echo "</br>";
echo "123456a";
echo "</br>";
echo "123456a.";
echo "</br>";
echo "123456abc";
echo "</br>";
echo "123456abc.";
echo "</br>";
echo "abc123456";
echo "</br>";
echo "abc123456.";
echo "</br>";
echo "woaini1314";
echo "</br>";
echo "woaini1314.";
echo "</br>";
echo "qq123456";
echo "</br>";
echo "qq123456.";
echo "</br>";
echo "woaini520";
echo "</br>";
echo "woaini520.";
echo "</br>";
echo "woaini123";
echo "</br>";
echo "woaini123.";
echo "</br>";
echo "woaini521";
echo "</br>";
echo "woaini521.";
echo "</br>";
echo "qazwsx";
echo "</br>";
echo "qazwsx.";
echo "</br>";
echo "1qaz2wsx";
echo "</br>";
echo "1qaz2wsx.";
echo "</br>";
echo "1q2w3e4r";
echo "</br>";
echo "1q2w3e4r.";
echo "</br>";
echo "1q2w3e4r5t";
echo "</br>";
echo "1q2w3e4r5t.";
echo "</br>";
echo "1q2w3e";
echo "</br>";
echo "1q2w3e.";
echo "</br>";
echo "qwertyuiop";
echo "</br>";
echo "qwertyuiop.";
echo "</br>";
echo "zxcvbnm";
echo "</br>";
echo "zxcvbnm.";
echo "</br>";
echo "123456";
echo "</br>";
echo "a123456";
echo "</br>";
echo "123456a";
echo "</br>";
echo "5201314";
echo "</br>";
echo "111111";
echo "</br>";
echo "woaini1314";
echo "</br>";
echo "qq123456";
echo "</br>";
echo "123123";
echo "</br>";
echo "000000";
echo "</br>";
echo "1qaz2wsx";
echo "</br>";
echo "1q2w3e4r";
echo "</br>";
echo "qwe123";
echo "</br>";
echo "7758521";
echo "</br>";
echo "123qwe";
echo "</br>";
echo "a123123";
echo "</br>";
echo "123456aa";
echo "</br>";
echo "woaini520";
echo "</br>";
echo "woaini";
echo "</br>";
echo "100200";
echo "</br>";
echo "1314520";
echo "</br>";
echo "woaini123";
echo "</br>";
echo "123321";
echo "</br>";
echo "q123456";
echo "</br>";
echo "123456789";
echo "</br>";
echo "123456789a";
echo "</br>";
echo "5211314";
echo "</br>";
echo "asd123";
echo "</br>";
echo "a123456789";
echo "</br>";
echo "z123456";
echo "</br>";
echo "asd123456";
echo "</br>";
echo "a5201314";
echo "</br>";
echo "aa123456";
echo "</br>";
echo "zhang123";
echo "</br>";
echo "aptx4869";
echo "</br>";
echo "123123a";
echo "</br>";
echo "1q2w3e4r5t";
echo "</br>";
echo "1qazxsw2";
echo "</br>";
echo "5201314a";
echo "</br>";
echo "1q2w3e";
echo "</br>";
echo "aini1314";
echo "</br>";
echo "31415926";
echo "</br>";
echo "q1w2e3r4";
echo "</br>";
echo "123456qq";
echo "</br>";
echo "woaini521";
echo "</br>";
echo "1234qwer";
echo "</br>";
echo "a111111";
echo "</br>";
echo "520520";
echo "</br>";
echo "iloveyou";
echo "</br>";
echo "abc123";
echo "</br>";
echo "110110";
echo "</br>";
echo "111111a";
echo "</br>";
echo "123456abc";
echo "</br>";
echo "w123456";
echo "</br>";
echo "7758258";
echo "</br>";
echo "123qweasd";
echo "</br>";
echo "159753";
echo "</br>";
echo "qwer1234";
echo "</br>";
echo "a000000";
echo "</br>";
echo "qq123123";
echo "</br>";
echo "zxc123";
echo "</br>";
echo "123654";
echo "</br>";
echo "abc123456";
echo "</br>";
echo "123456q";
echo "</br>";
echo "qq5201314";
echo "</br>";
echo "12345678";
echo "</br>";
echo "000000a";
echo "</br>";
echo "456852";
echo "</br>";
echo "as123456";
echo "</br>";
echo "1314521";
echo "</br>";
echo "112233";
echo "</br>";
echo "521521";
echo "</br>";
echo "qazwsx123";
echo "</br>";
echo "zxc123456";
echo "</br>";
echo "abcd1234";
echo "</br>";
echo "asdasd";
echo "</br>";
echo "666666";
echo "</br>";
echo "love1314";
echo "</br>";
echo "QAZ123";
echo "</br>";
echo "aaa123";
echo "</br>";
echo "q1w2e3";
echo "</br>";
echo "aaaaaa";
echo "</br>";
echo "a123321";
echo "</br>";
echo "123000";
echo "</br>";
echo "11111111";
echo "</br>";
echo "12qwaszx";
echo "</br>";
echo "5845201314";
echo "</br>";
echo "s123456";
echo "</br>";
echo "nihao123";
echo "</br>";
echo "caonima123";
echo "</br>";
echo "zxcvbnm123";
echo "</br>";
echo "wang123";
echo "</br>";
echo "159357";
echo "</br>";
echo "1A2B3C4D";
echo "</br>";
echo "asdasd123";
echo "</br>";
echo "584520";
echo "</br>";
echo "753951";
echo "</br>";
echo "147258";
echo "</br>";
echo "1123581321";
echo "</br>";
echo "110120";
echo "</br>";
echo "qq1314520";
echo "</br>";
echo "li123";
echo "</br>";
echo "li123456";
echo "</br>";
echo "wang123456";
echo "</br>";
echo "zhang123";
echo "</br>";
echo "zhang123456";
echo "</br>";
echo "liu123";
echo "</br>";
echo "liu123456";
echo "</br>";
echo "chen123";
echo "</br>";
echo "chen123456";
echo "</br>";
echo "yang123";
echo "</br>";
echo "yang123456";
echo "</br>";
echo "zhao123";
echo "</br>";
echo "zhao123456";
echo "</br>";
echo "huang123";
echo "</br>";
echo "huang123456";
echo "</br>";
echo "zhou123";
echo "</br>";
echo "zhou123456";
echo "</br>";
echo "wu123";
echo "</br>";
echo "wu123456";
echo "</br>";
echo "')or('a'='a";
echo "</br>";
echo "or 1=1--";
echo "</br>";
echo "'or'='or'";
echo "</br>";
echo "'or 1=1--";
echo "</br>";
echo "'or'a'='a";
echo "</br>";
echo "'or'1'='1";
echo "</br>";

?>
